
import 'svga_240816_platform_interface.dart';

class Svga240816 {
  Future<String?> getPlatformVersion() {
    return Svga240816Platform.instance.getPlatformVersion();
  }
}
