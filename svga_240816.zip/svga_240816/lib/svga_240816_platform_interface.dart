import 'package:plugin_platform_interface/plugin_platform_interface.dart';

import 'svga_240816_method_channel.dart';

abstract class Svga240816Platform extends PlatformInterface {
  /// Constructs a Svga240816Platform.
  Svga240816Platform() : super(token: _token);

  static final Object _token = Object();

  static Svga240816Platform _instance = MethodChannelSvga240816();

  /// The default instance of [Svga240816Platform] to use.
  ///
  /// Defaults to [MethodChannelSvga240816].
  static Svga240816Platform get instance => _instance;

  /// Platform-specific implementations should set this with their own
  /// platform-specific class that extends [Svga240816Platform] when
  /// they register themselves.
  static set instance(Svga240816Platform instance) {
    PlatformInterface.verifyToken(instance, _token);
    _instance = instance;
  }

  Future<String?> getPlatformVersion() {
    throw UnimplementedError('platformVersion() has not been implemented.');
  }
}
