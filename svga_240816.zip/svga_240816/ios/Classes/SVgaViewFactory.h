//
//  SVgaViewFactory.h
//  Pods
//
//  Created by MAC on 2024/8/17.
//

#ifndef SVgaViewFactory_h
#define SVgaViewFactory_h
#import <Foundation/Foundation.h>
#import<Flutter/Flutter.h>
@interface SVgaViewFactory : NSObject <FlutterPlatformViewFactory>
- (instancetype)initWithRegistrar: (NSObject<FlutterPluginRegistrar> *) registrar;
@end

#endif /* SVgaViewFactory_h */
