#import <Flutter/Flutter.h>

@interface Svga240816Plugin : NSObject<FlutterPlugin>
@end
