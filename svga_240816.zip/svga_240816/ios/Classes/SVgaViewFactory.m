//
//  SVgaViewFactory.m
//  path_provider_foundation
//
//  Created by MAC on 2024/8/17.
//

#import <Foundation/Foundation.h>
#import "SVgaViewFactory.h"
#import "SVgaView.h"
@implementation SVgaViewFactory  {
    NSObject<FlutterPluginRegistrar> * _registrar;
}

- (instancetype)initWithRegistrar: (NSObject<FlutterPluginRegistrar> *) registrar{
    self = [super init];
    if (self) {
        _registrar = registrar;
    }
    return self;
}

- (NSObject<FlutterPlatformView> *)createWithFrame: (CGRect) frame
                                    viewIdentifier:(int64_t)viewId
                                         arguments:(id _Nullable)args {
    return [[SVgaView alloc] initWithFrame:frame
                            viewIdentifier:viewId
                                 arguments:args
                                mRegistrar:_registrar];
}

@end
