//
//  SVgaview.m
//  path_provider_foundation
//
//  Created by MAC on 2024/8/17.
//

#import <Foundation/Foundation.h>
#import "SVgaView.h"
#import "SVGAPlayer.h"
#import "SVGAParser.h"
#import "SVGAImageView.h"
@implementation SVgaView {
    UIView *_view;
    NSObject<FlutterPluginRegistrar> * _registrar;
    FlutterResult _result;
    SVGAImageView* _svgaPlayer;
}

- (instancetype _Nullable )initWithFrame: (CGRect) frame
               viewIdentifier: (int64_t) viewId
                    arguments: (id _Nullable) args
                    mRegistrar: (NSObject<FlutterPluginRegistrar> *_Nullable) registrar{
    if (self == [super init]) {
        _view = [[UIView alloc] initWithFrame:frame];
        _view.backgroundColor = [UIColor yellowColor];
        _registrar = registrar;
        _svgaPlayer = [[SVGAImageView alloc] initWithFrame:CGRectMake(0, 0, 300, 300)];
        _svgaPlayer.loops = 1;
        
        _svgaPlayer.backgroundColor = [UIColor colorWithRed:(39/255.0) green:(114/255.0) blue:(139/255.0) alpha:1.0];
        [_view addSubview: _svgaPlayer];
        _svgaPlayer.delegate = self;
        ///拿参数
        NSDictionary* dic = args;
//        NSNumber* nLoopCnt = dic[@"loopCnt"];
        NSString* channelName = @"flutter_sVag_view_";
        NSString* viewIdString = [NSString stringWithFormat:@"%lld",viewId];
        NSString* result = [channelName stringByAppendingString:viewIdString];
        NSLog(@"%@",result);
        FlutterMethodChannel* channel = [FlutterMethodChannel
            methodChannelWithName:result
                  binaryMessenger:registrar.messenger];
        
        [registrar addMethodCallDelegate: self channel:channel];
        
    }
    return self;
    
}

#pragma mark --解析完成的回调
- (void)handleParseItem:(SVGAVideoEntity *)videoItem {
    _svgaPlayer.videoItem = videoItem;
    [self.view addSubview:_svg]
    [_svgaPlayer startAnimation];
}

-  (void)handleParseItemError:(NSError*)error{
    
}

#pragma mark --播放状态回调
- (void)svgaPlayerDidFinishedAnimation:(SVGAPlayer *)player{
    NSLog(@"%@",@"finished");
}

- (void)svgaPlayerDidAnimatedToFrame:(NSInteger)frame{
    
}

- (void)svgaPlayerDidAnimatedToPercentage:(CGFloat)percentage{
    NSLog(@"%f",percentage);
}

#pragma mark --flutter调native回调
- (void)handleMethodCall:(FlutterMethodCall*)call result:(FlutterResult)result {
    _result = result;
    NSLog(@"%@",call.method);
    if ([@"playUrl" isEqualToString: call.method]) {
        NSString* urlPath = call.arguments[@"url"];
        SVGAParser* parse = [[SVGAParser alloc] init];
        __weak __typeof(self)weakSelf = self;
        [parse parseWithURL:[NSURL URLWithString:urlPath] completionBlock:^(SVGAVideoEntity * _Nullable videoItem) {
            [weakSelf handleParseItem:videoItem];
        } failureBlock:^(NSError * _Nullable error) {
            [weakSelf handleParseItemError:error];
        }];
    } else if ([@"playAsset" isEqualToString:call.method]) {
        //播放asset文件
        NSString* assetPath = [_registrar lookupKeyForAsset:call.arguments[@"asset"]];
        NSString* path = [[NSBundle mainBundle] pathForResource:assetPath ofType:nil];
//        [self playByPath:path];
    } else if ([@"stop" isEqualToString:call.method]) {

    }
}
- (UIView*)view {
    
    return _view;
}

@end
