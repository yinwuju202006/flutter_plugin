//
//  SVgaView.h
//  Pods
//
//  Created by MAC on 2024/8/17.
//

#ifndef SVgaView_h
#define SVgaView_h

#import <Foundation/Foundation.h>
#import <Flutter/Flutter.h>
#import "SVGAParser.h"
#import "SVGAPlayer.h"
@interface SVgaView : NSObject <FlutterPlatformView,SVGAPlayerDelegate>
- (instancetype _Nullable )initWithFrame: (CGRect) frame
               viewIdentifier: (int64_t) viewId
                    arguments: (id _Nullable) args
                   mRegistrar: (NSObject<FlutterPluginRegistrar> *_Nullable) registrar;

- (UIView*) view;
@end


#endif /* SVgaView_h */
