package com.example.svga_240816_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
