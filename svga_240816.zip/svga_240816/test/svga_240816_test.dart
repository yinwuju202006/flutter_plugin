import 'package:flutter_test/flutter_test.dart';
import 'package:svga_240816/svga_240816.dart';
import 'package:svga_240816/svga_240816_platform_interface.dart';
import 'package:svga_240816/svga_240816_method_channel.dart';
import 'package:plugin_platform_interface/plugin_platform_interface.dart';

class MockSvga240816Platform
    with MockPlatformInterfaceMixin
    implements Svga240816Platform {

  @override
  Future<String?> getPlatformVersion() => Future.value('42');
}

void main() {
  final Svga240816Platform initialPlatform = Svga240816Platform.instance;

  test('$MethodChannelSvga240816 is the default instance', () {
    expect(initialPlatform, isInstanceOf<MethodChannelSvga240816>());
  });

  test('getPlatformVersion', () async {
    Svga240816 svga240816Plugin = Svga240816();
    MockSvga240816Platform fakePlatform = MockSvga240816Platform();
    Svga240816Platform.instance = fakePlatform;

    expect(await svga240816Plugin.getPlatformVersion(), '42');
  });
}
